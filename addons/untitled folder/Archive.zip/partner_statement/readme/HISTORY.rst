12.0.1.0.0 (2018-11-08)
~~~~~~~~~~~~~~~~~~~~~~~

* [BREAKING] Modules customer_activity_statement and customer_outstanding_statement merged to create partner_statement.
* [ADD] New features.
  * Age by months or days
  * Filter negative balances
